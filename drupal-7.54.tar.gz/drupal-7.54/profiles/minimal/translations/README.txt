
This directory should be used to place downloaded translations
for installing Drupal core.
